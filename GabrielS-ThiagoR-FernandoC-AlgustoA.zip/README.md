Banco Automítico
